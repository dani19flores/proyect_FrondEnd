$(document).ready(function () {
    $('#productsContainer').load('../home.html');
});