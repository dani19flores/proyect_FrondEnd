$(document).ready(function () {
    $('#contactContainer').load('../contact.html');
});

